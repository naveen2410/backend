from django.shortcuts import render

# Create your views here.
from django.shortcuts import render
from rest_framework import viewsets          # add this
from .serializers import UserDetailsSerializer      # add this
from .models import UserDetails                    # add this

class UserDetailsView(viewsets.ModelViewSet):       # add this
    serializer_class = UserDetailsSerializer          # add this
    queryset = UserDetails.objects.all()              # add this