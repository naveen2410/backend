from django.contrib import admin
from .models import UserDetails # add this
# Register your models here.

class UserDetailsAdmin(admin.ModelAdmin):  # add this
    list_display = ('firstname', 'lastname', 'email', 'password', 'role1') # add this

    # Register your models here.
admin.site.register(UserDetails, UserDetailsAdmin) # add this