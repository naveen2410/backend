#from django.test import TestCase
from django.db import models
#from models import UserDetails
from django.contrib.auth.models import User

# Create your tests here.

print("Hello")
#print(models._meta.get_all_field_names())
print(User.objects.values_list())