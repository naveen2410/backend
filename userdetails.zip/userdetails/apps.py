from django.apps import AppConfig


class UserdetailsConfig(AppConfig):
    name = 'userdetails'
