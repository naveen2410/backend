from django.db import models

# Create your models here.
 # add this
class UserDetails(models.Model):
    firstname = models.CharField(max_length=120)
    lastname = models.CharField(max_length=120)
    email = models.CharField(max_length=120)
    role1 = models.CharField(max_length=120, null=True)
    password = models.TextField()
    
    def _str_(self):
        return self.firstname